library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

library work;
use work.HD_Package.ALL;

-- Modifications :
-- Ajout de deux buffers de segment (query et class) permettant de sélectionner un slice spécifique
-- Chargement du buffer effectué en parallèle

entity HD_PE is
    generic (
        VECTOR_WIDTH  : natural := 8192;
        SLICE_WIDTH   : natural := 64;
        SEGMENT_WIDTH : natural := 512
    );
    port (
        clk  : in std_logic;
        rstn : in std_logic;

        PE_acc_clear_input   : in  std_logic;
        PE_acc_enable_input  : in  std_logic;
        PE_load_input        : in  std_logic;

        PE_segment_BHV_input : in  std_logic_vector(SEGMENT_WIDTH - 1 downto 0);
        PE_segment_QHV_input : in  std_logic_vector(SEGMENT_WIDTH - 1 downto 0);

        
        PE_done_output    : out std_logic;
        PE_HamDist_output : out std_logic_vector(log2c(VECTOR_WIDTH) - 1 downto 0)
    );
end entity;

architecture Behavioral of HD_PE is

    constant SLICES_PER_BLOCK : natural := SEGMENT_WIDTH / SLICE_WIDTH;
    
    -- Nouveau Buffer
    component SEGMENT_BUFFER is
        generic(
                VECTOR_WIDTH : natural;
                SEGMENT_WIDTH: natural;
                SLICE_WIDTH : natural
        );
        port(
            clk                  : in  std_logic;
            rstn                 : in  std_logic;
            PE_load_input        : in  std_logic;
            PE_segment_BHV_input : in  std_logic_vector(SEGMENT_WIDTH - 1 downto 0);
            PE_segment_QHV_input : in  std_logic_vector(SEGMENT_WIDTH - 1 downto 0);
            PE_acc_enable_input  : in  std_logic;
            PE_done_output       : out std_logic;
            bhv_slice            : out std_logic_vector(SLICE_WIDTH - 1 downto 0);
            qhv_slice            : out std_logic_vector(SLICE_WIDTH - 1 downto 0)
        );
    end component;
        
    component XOR_slice is
        generic (SLICE_WIDTH : natural);
        port (
            XOR_slice_input_1 : in  std_logic_vector(SLICE_WIDTH - 1 downto 0);
            XOR_slice_input_2 : in  std_logic_vector(SLICE_WIDTH - 1 downto 0);
            XOR_slice_output  : out std_logic_vector(SLICE_WIDTH - 1 downto 0)
        );
    end component;

    component PSUM is
        generic (SLICE_WIDTH : natural);
        port (
            PSUM_slice_input : in  std_logic_vector(SLICE_WIDTH - 1 downto 0);
            PSUM_sum_output  : out std_logic_vector(log2c(SLICE_WIDTH) - 1 downto 0)
        );
    end component;

    component ACC is
        generic (
            VECTOR_WIDTH : natural;
            SLICE_WIDTH  : natural
        );
        port (
            clk                : in  std_logic;
            rstn               : in  std_logic;
            ACC_clear_input    : in  std_logic;
            ACC_enable_input   : in  std_logic;
            ACC_sum_input      : in  std_logic_vector(log2c(SLICE_WIDTH) - 1 downto 0);
            ACC_HamDist_output : out std_logic_vector(log2c(VECTOR_WIDTH) - 1 downto 0)
        );
    end component;
    

    -- Signaux associés aux buffers
    signal bhv_slice  : std_logic_vector(SLICE_WIDTH - 1 downto 0);
    signal qhv_slice  : std_logic_vector(SLICE_WIDTH - 1 downto 0);

    signal xor_out  : std_logic_vector(SLICE_WIDTH - 1 downto 0);
    signal psum_out : std_logic_vector(log2c(SLICE_WIDTH) - 1 downto 0);

begin

    BUF_0 : SEGMENT_BUFFER
        generic map (
            VECTOR_WIDTH  => VECTOR_WIDTH,
            SEGMENT_WIDTH => SEGMENT_WIDTH,
            SLICE_WIDTH   => SLICE_WIDTH
        )
        port map (
            clk                  => clk,
            rstn                 => rstn,
            PE_load_input        => PE_load_input,
            PE_segment_BHV_input => PE_segment_BHV_input,
            PE_segment_QHV_input => PE_segment_QHV_input,
            PE_acc_enable_input  => PE_acc_enable_input,
            PE_done_output       => PE_done_output,
            bhv_slice            => bhv_slice,
            qhv_slice            => qhv_slice
        );

    
    -- Composants du PE demeurés inchangés
    XOR_0 : XOR_slice
        generic map (SLICE_WIDTH => SLICE_WIDTH)
        port map (
            XOR_slice_input_1 => bhv_slice,
            XOR_slice_input_2 => qhv_slice,
            XOR_slice_output  => xor_out
        );

    PSUM_0 : PSUM
        generic map (SLICE_WIDTH => SLICE_WIDTH)
        port map (
            PSUM_slice_input => xor_out,
            PSUM_sum_output  => psum_out
        );

    ACC_0 : ACC
        generic map (
            VECTOR_WIDTH => VECTOR_WIDTH,
            SLICE_WIDTH  => SLICE_WIDTH
        )
        port map (
            clk                => clk,
            rstn               => rstn,
            ACC_clear_input    => PE_acc_clear_input,
            ACC_enable_input   => PE_acc_enable_input,
            ACC_sum_input      => psum_out,
            ACC_HamDist_output => PE_HamDist_output
        );

end Behavioral;