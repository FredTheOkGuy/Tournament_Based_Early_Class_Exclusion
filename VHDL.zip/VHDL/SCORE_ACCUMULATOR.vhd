library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

library work;
use work.HD_Package.ALL;

entity SCORE_ACCUMULATOR is
    generic (
        NBR_ACC         : natural := 8;
        HD_WIDTH        : natural := 8;
        SCORE_WIDTH     : natural := 8;
        ROUND_WIDTH     : natural := 3;
        PAIR_WIDTH      : natural := 4
    );
    port (
        PE_HamDist_input : in bus_array(0 to NBR_ACC - 1)(HD_WIDTH - 1 downto 0);

        round_idx_input : in std_logic_vector(ROUND_WIDTH - 1 downto 0);
        pair_idx_input  : in std_logic_vector(PAIR_WIDTH - 1 downto 0);

        score_a_output : out std_logic_vector(SCORE_WIDTH - 1 downto 0);
        score_b_output : out std_logic_vector(SCORE_WIDTH - 1 downto 0)
    );
end entity;

architecture Behavioral of SCORE_ACCUMULATOR is
begin

    process(PE_HamDist_input, round_idx_input, pair_idx_input)
        variable sum_a      : unsigned(SCORE_WIDTH - 1 downto 0);
        variable sum_b      : unsigned(SCORE_WIDTH - 1 downto 0);
        variable hd_i       : std_logic_vector(HD_WIDTH - 1 downto 0);
        variable group_size : integer range 1 to NBR_ACC;
        variable pair_idx   : integer range 0 to NBR_ACC / 2;
        variable base_a     : integer range 0 to NBR_ACC - 1;
        variable base_b     : integer range 0 to NBR_ACC - 1;
    begin
        sum_a := (others => '0');
        sum_b := (others => '0');

        group_size := 1;
        for r in 0 to NBR_ACC loop
            if r < to_integer(unsigned(round_idx_input)) then
                group_size := group_size * 2;
            end if;
        end loop;

        pair_idx := to_integer(unsigned(pair_idx_input));
        base_a := pair_idx * 2 * group_size;
        base_b := base_a + group_size;

        for i in 0 to NBR_ACC - 1 loop
            hd_i := PE_HamDist_input(i);

            if (i >= base_a) and (i < base_a + group_size) then
                sum_a := sum_a + resize(unsigned(hd_i), SCORE_WIDTH);
            end if;

            if (i >= base_b) and (i < base_b + group_size) then
                sum_b := sum_b + resize(unsigned(hd_i), SCORE_WIDTH);
            end if;
        end loop;

        score_a_output <= std_logic_vector(sum_a);
        score_b_output <= std_logic_vector(sum_b);
    end process;

end Behavioral;
