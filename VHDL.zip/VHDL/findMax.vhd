library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity findMax is
    generic (
        SCORE_WIDTH : natural;
        CLASS_IDX_WIDTH : natural
    );
    port (
        score_a_input    : in  std_logic_vector(SCORE_WIDTH - 1 downto 0);
        score_b_input    : in  std_logic_vector(SCORE_WIDTH - 1 downto 0);
        class_a_input    : in  std_logic_vector(CLASS_IDX_WIDTH - 1 downto 0);
        class_b_input    : in  std_logic_vector(CLASS_IDX_WIDTH - 1 downto 0);
        loser_idx_output : out std_logic_vector(CLASS_IDX_WIDTH - 1 downto 0)
    );
end entity;

-- Le findMax compare seulement deux classes à la fois,
-- il a donc été adapté en conséquence, ce qui le réduit à un
-- unique comparateur
architecture Behavioral of findMax is
begin

    process(score_a_input, score_b_input, class_a_input, class_b_input)
    begin
        if unsigned(score_a_input) >= unsigned(score_b_input) then
            loser_idx_output <= class_a_input;
        else
            loser_idx_output <= class_b_input;
        end if;
    end process;

end Behavioral;