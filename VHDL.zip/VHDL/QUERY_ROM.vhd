library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

library work;
use work.HD_Package.ALL;
use work.HV_ROM_Package.ALL;

entity QUERY_ROM is
    generic (
        ADDR_OFFSET_QHV : natural := 24;
        NBR_QUERY       : natural := 12;
        SEGMENT_WIDTH   : natural := 2048;
        NBR_SEG         : natural := 4
    );
    port (
        clk : in std_logic;
        query_idx_input : in std_logic_vector(log2c(NBR_QUERY - 1) - 1 downto 0);
        addr_seg_input  : in std_logic_vector(log2c(NBR_SEG - 1) - 1 downto 0);
        segment_output  : out std_logic_vector(SEGMENT_WIDTH - 1 downto 0)
    );
end entity;

architecture Behavioral of QUERY_ROM is

    constant NBR_WORDS : natural := NBR_QUERY * NBR_SEG;

    type query_rom_array is array(0 to NBR_WORDS - 1) of
        std_logic_vector(SEGMENT_WIDTH - 1 downto 0);

    function init_query_rom return query_rom_array is
        variable tmp : query_rom_array;
        variable hv_idx : natural;
        variable word_idx : natural;
    begin
        for q in 0 to NBR_QUERY - 1 loop
            hv_idx := ADDR_OFFSET_QHV + q;
            for s in 0 to NBR_SEG - 1 loop
                word_idx := q * NBR_SEG + s;
                if hv_idx < HV_NBR_ADDRESS then
                    tmp(word_idx) := HV_ROM_DATA(hv_idx)((s + 1) * SEGMENT_WIDTH - 1 downto s * SEGMENT_WIDTH);
                else
                    tmp(word_idx) := (others => '0');
                end if;
            end loop;
        end loop;
        return tmp;
    end function;

    signal ROM : query_rom_array := init_query_rom;

    attribute rom_style : string;
    attribute rom_style of ROM : signal is "block";

begin

    process(clk)
        variable word_idx : natural range 0 to NBR_WORDS - 1;
    begin
        if rising_edge(clk) then
            word_idx := to_integer(unsigned(query_idx_input)) * NBR_SEG +
                        to_integer(unsigned(addr_seg_input));
            segment_output <= ROM(word_idx);
        end if;
    end process;

end Behavioral;
