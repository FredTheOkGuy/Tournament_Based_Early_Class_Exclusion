library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
entity SEGMENT_BUFFER is
    generic(
        VECTOR_WIDTH  : natural;
        SEGMENT_WIDTH : natural;
        SLICE_WIDTH   : natural
    );
    port(
        clk  : in std_logic;
        rstn : in std_logic;
        PE_load_input : in std_logic;
        PE_segment_BHV_input : in std_logic_vector(SEGMENT_WIDTH - 1 downto 0);
        PE_segment_QHV_input : in std_logic_vector(SEGMENT_WIDTH - 1 downto 0);
        PE_acc_enable_input : in  std_logic;
        PE_done_output      : out std_logic;
        bhv_slice : out std_logic_vector(SLICE_WIDTH - 1 downto 0);
        qhv_slice : out std_logic_vector(SLICE_WIDTH - 1 downto 0)
    );
end entity;
architecture Behavioral of SEGMENT_BUFFER is
    constant SLICES_PER_BLOCK : natural := SEGMENT_WIDTH / SLICE_WIDTH;
    -- Signaux associés aux buffers (registre de requête, registre de classe et compteur de slice)
    signal bhv_shift_reg : std_logic_vector(SEGMENT_WIDTH - 1 downto 0);
    signal qhv_shift_reg : std_logic_vector(SEGMENT_WIDTH - 1 downto 0);
    signal slice_ctr : natural range 0 to SLICES_PER_BLOCK;
begin
    process(clk, rstn)
    begin
        if rstn = '0' then
            bhv_shift_reg <= (others => '0');
            qhv_shift_reg <= (others => '0');
            slice_ctr     <= 0;
        elsif rising_edge(clk) then
            if PE_load_input = '1' then
                bhv_shift_reg <= PE_segment_BHV_input;
                qhv_shift_reg <= PE_segment_QHV_input;
                slice_ctr     <= 0;
            elsif PE_acc_enable_input = '1' then
                bhv_shift_reg <=
                    (SLICE_WIDTH - 1 downto 0 => '0') &
                    bhv_shift_reg(SEGMENT_WIDTH - 1 downto SLICE_WIDTH);
                qhv_shift_reg <=
                    (SLICE_WIDTH - 1 downto 0 => '0') &
                    qhv_shift_reg(SEGMENT_WIDTH - 1 downto SLICE_WIDTH);
                if slice_ctr < SLICES_PER_BLOCK - 1 then
                    slice_ctr <= slice_ctr + 1;
                end if;
            end if;
        end if;
    end process;
    -- Buffer ajouté
    -- Permet d'accumuler le score de toutes les slices
    -- du segment, une à la fois
    -- Indique lorsque le PE a terminé son traitement, puisque tous les PE d'une classe
    -- doivent avoir terminé avant d'exécuter le findMax
    PE_done_output <= '1' when
        (PE_acc_enable_input = '1' and slice_ctr = SLICES_PER_BLOCK - 1)
        else '0';
    bhv_slice <= bhv_shift_reg(SLICE_WIDTH - 1 downto 0);
    qhv_slice <= qhv_shift_reg(SLICE_WIDTH - 1 downto 0);
end Behavioral;