library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

library work;
use work.HD_Package.ALL;

entity tb_PU is
end tb_PU;

architecture Behavioral of tb_PU is

    constant CLK_PERIOD      : time    := 2 ns;
    constant ACTUAL_NBR_CLASS: natural := 6;
    constant NBR_CLASS       : natural := next_power_of_two(ACTUAL_NBR_CLASS);
    constant NBR_QUERIES     : natural := 4;
    constant VECTOR_WIDTH    : natural := 8192;
    constant SLICE_WIDTH     : natural := 32;
    constant SEGMENT_WIDTH   : natural := 512;
    constant ADDR_OFFSET_QHV : natural := 32;
    constant NBR_ADDRESS     : natural := 36;
    constant QUERY_IDX_W     : natural := log2c(NBR_QUERIES - 1);

    signal clk        : std_logic := '0';
    signal rstn       : std_logic := '0';
    signal start      : std_logic := '0';
    signal ready      : std_logic;
    signal query_idx  : std_logic_vector(QUERY_IDX_W - 1 downto 0) := (others => '0');
    signal prediction : std_logic_vector(log2c(NBR_CLASS - 1) - 1 downto 0);

begin

    DUT : entity work.PU
        generic map (
            NBR_CLASS       => NBR_CLASS,
            VECTOR_WIDTH    => VECTOR_WIDTH,
            SLICE_WIDTH     => SLICE_WIDTH,
            SEGMENT_WIDTH   => SEGMENT_WIDTH,
            NBR_ADDRESS     => NBR_ADDRESS,
            ADDR_OFFSET_QHV => ADDR_OFFSET_QHV
        )
        port map (
            clk                           => clk,
            rstn                          => rstn,
            PU_start_input                => start,
            PU_ready_output               => ready,
            PU_query_idx_input            => query_idx,
            PU_predicted_class_idx_output => prediction
        );

    clk_proc : process
    begin
        loop
            clk <= '0';
            wait for CLK_PERIOD / 2;
            clk <= '1';
            wait for CLK_PERIOD / 2;
        end loop;
    end process;

    stim_proc : process
    begin
        rstn  <= '0';
        start <= '0';

        wait for 4 * CLK_PERIOD;
        rstn <= '1';

        loop
            wait until rising_edge(clk);
            exit when ready = '1';
        end loop;

        for q in 0 to NBR_QUERIES - 1 loop

            query_idx <= std_logic_vector(to_unsigned(q, QUERY_IDX_W));

            wait until rising_edge(clk);
            start <= '1';

            wait until rising_edge(clk);
            start <= '0';

            loop
                wait until rising_edge(clk);
                exit when ready = '1';
            end loop;

            report "Query " & integer'image(q)
                & " done. Predicted class = "
                & integer'image(to_integer(unsigned(prediction)));

        end loop;

        report "Simulation complete.";
        wait;
    end process;

end Behavioral;