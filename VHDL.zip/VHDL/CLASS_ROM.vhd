library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

library work;
use work.HD_Package.ALL;
use work.HV_ROM_Package.ALL;

entity CLASS_ROM is
    generic (
        CLASS_ID      : natural := 0;
        SEGMENT_WIDTH : natural := 2048;
        NBR_SEG       : natural := 4
    );
    port (
        clk : in std_logic;
        addr_seg_input : in std_logic_vector(log2c(NBR_SEG - 1) - 1 downto 0);
        segment_output : out std_logic_vector(SEGMENT_WIDTH - 1 downto 0)
    );
end entity;

architecture Behavioral of CLASS_ROM is

    type segment_rom_array is array(0 to NBR_SEG - 1) of
        std_logic_vector(SEGMENT_WIDTH - 1 downto 0);

    function init_class_rom return segment_rom_array is
        variable tmp : segment_rom_array;
    begin
        for i in 0 to NBR_SEG - 1 loop
            if CLASS_ID < HV_NBR_ADDRESS then
                tmp(i) := HV_ROM_DATA(CLASS_ID)((i + 1) * SEGMENT_WIDTH - 1 downto i * SEGMENT_WIDTH);
            else
                tmp(i) := (others => '0');
            end if;
        end loop;
        return tmp;
    end function;

    signal ROM : segment_rom_array := init_class_rom;

    attribute rom_style : string;
    attribute rom_style of ROM : signal is "block";

begin

    process(clk)
    begin
        if rising_edge(clk) then
            segment_output <= ROM(to_integer(unsigned(addr_seg_input)));
        end if;
    end process;

end Behavioral;
