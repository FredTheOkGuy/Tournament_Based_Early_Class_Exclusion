library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

library work;
use work.HD_Package.ALL;

entity PU is
    generic (
        NBR_CLASS       : natural := 26;
        VECTOR_WIDTH    : natural := 8192;
        SLICE_WIDTH     : natural := 16;
        SEGMENT_WIDTH   : natural := 256;
        NBR_ADDRESS     : natural := 34;
        ADDR_OFFSET_QHV : natural := 32
    );
    port (
        clk  : in std_logic;
        rstn : in std_logic;

        PU_start_input  : in  std_logic;
        PU_ready_output : out std_logic;
        PU_query_idx_input : in std_logic_vector(log2c(NBR_ADDRESS - ADDR_OFFSET_QHV - 1) - 1 downto 0);
        PU_predicted_class_idx_output : out std_logic_vector(log2c(NBR_CLASS - 1) - 1 downto 0)
    );
end entity;

architecture Behavioral of PU is

    -- All the signals needed for the tournament
    constant NBR_CLASS_NEXT_POW2   : natural := next_power_of_two(NBR_CLASS);
    constant NBR_ACC               : natural := NBR_CLASS_NEXT_POW2;
    constant NBR_SEG               : natural := VECTOR_WIDTH / SEGMENT_WIDTH;
    constant CLASS_IDX_WIDTH       : natural := log2c(NBR_CLASS_NEXT_POW2 - 1);
    constant HD_WIDTH              : natural := log2c(VECTOR_WIDTH);
    constant SEG_ADDR_WIDTH        : natural := log2c(NBR_SEG - 1);
    constant NBR_QUERY             : natural := NBR_ADDRESS - ADDR_OFFSET_QHV;
    constant SCORE_WIDTH           : natural := HD_WIDTH + log2c(NBR_ACC);
    constant NBR_ROUNDS            : natural := log2c(NBR_CLASS_NEXT_POW2 - 1);
    constant ROUND_WIDTH           : natural := log2c(NBR_ROUNDS - 1);
    constant PAIR_WIDTH            : natural := log2c((NBR_CLASS_NEXT_POW2 / 2) - 1);
    
    -- FSMD Component   
    component FSMD is
        generic (
            NBR_CLASS           : natural;
            NBR_CLASS_NEXT_POW2 : natural;
            VECTOR_WIDTH        : natural;
            SLICE_WIDTH         : natural;
            SEGMENT_WIDTH       : natural
        );
        port (
            clk  : in std_logic;
            rstn : in std_logic;

            fsmd_start_input  : in  std_logic;
            fsmd_ready_output : out std_logic;

            fsmd_PE_acc_clear_output  : out std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);
            fsmd_PE_acc_enable_output : out std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);
            fsmd_PE_load_output       : out std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);
            fsmd_PE_done_input        : in  std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);

            fsmd_MEM_addr_seg_output        : out std_logic_vector(log2c(NBR_SEG - 1) - 1 downto 0);

            fsmd_PE_class_output            : out bus_array(0 to NBR_CLASS_NEXT_POW2 - 1)(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1 downto 0);

            fsmd_compare_class_a_output     : out std_logic_vector(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1 downto 0);

            fsmd_compare_class_b_output     : out std_logic_vector(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1 downto 0);

            fsmd_compare_pair_idx_output    : out std_logic_vector(log2c((NBR_CLASS_NEXT_POW2 / 2) - 1) - 1 downto 0);

            fsmd_round_idx_output           : out std_logic_vector(log2c(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1) - 1 downto 0);

            fsmd_findmax_maxIdx_input       : in std_logic_vector(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1 downto 0);

            fsmd_predicted_class_idx_output : out std_logic_vector(log2c(NBR_CLASS - 1) - 1 downto 0)
        );
    end component;
    
    -- ROM for the Classes' Hypervector
    component CLASS_ROM is
        generic (
            CLASS_ID      : natural;
            SEGMENT_WIDTH : natural;
            NBR_SEG       : natural
        );
        port (
            clk            : in  std_logic;
            addr_seg_input : in  std_logic_vector(SEG_ADDR_WIDTH - 1 downto 0);
            segment_output : out std_logic_vector(SEGMENT_WIDTH - 1 downto 0)
        );
    end component;
    
    -- ROM for the Queries' Hypervector
    component QUERY_ROM is
        generic (
            ADDR_OFFSET_QHV : natural;
            NBR_QUERY       : natural;
            SEGMENT_WIDTH   : natural;
            NBR_SEG         : natural
        );
        port (
            clk             : in  std_logic;
            query_idx_input : in  std_logic_vector(log2c(NBR_QUERY - 1) - 1 downto 0);
            addr_seg_input  : in  std_logic_vector(SEG_ADDR_WIDTH - 1 downto 0);
            segment_output  : out std_logic_vector(SEGMENT_WIDTH - 1 downto 0)
        );
    end component;
    
    -- Processing Element
    component HD_PE is
        generic (
            VECTOR_WIDTH  : natural;
            SLICE_WIDTH   : natural;
            SEGMENT_WIDTH : natural
        );
        port (
            clk  : in std_logic;
            rstn : in std_logic;

            PE_acc_clear_input  : in std_logic;
            PE_acc_enable_input : in std_logic;
            PE_load_input       : in std_logic;

            PE_segment_BHV_input : in std_logic_vector(SEGMENT_WIDTH - 1 downto 0);
            PE_segment_QHV_input : in std_logic_vector(SEGMENT_WIDTH - 1 downto 0);

            PE_done_output    : out std_logic;
            PE_HamDist_output : out std_logic_vector(log2c(VECTOR_WIDTH) - 1 downto 0)
        );
    end component;
    
    -- Score accumulator, used for summing up PE values
    component SCORE_ACCUMULATOR is
        generic (
            NBR_ACC     : natural;
            HD_WIDTH    : natural;
            SCORE_WIDTH : natural;
            ROUND_WIDTH : natural;
            PAIR_WIDTH  : natural
        );
        port (
            PE_HamDist_input : in  bus_array(0 to NBR_ACC - 1)(HD_WIDTH - 1 downto 0);
            round_idx_input  : in  std_logic_vector(ROUND_WIDTH - 1 downto 0);
            pair_idx_input   : in  std_logic_vector(PAIR_WIDTH - 1 downto 0);
            score_a_output   : out std_logic_vector(SCORE_WIDTH - 1 downto 0);
            score_b_output   : out std_logic_vector(SCORE_WIDTH - 1 downto 0)
        );
    end component;
    
    -- Findmax component, this is a simple comparator between two values 
    -- (since comapring in pairs)
    component findMax is
        generic (
            SCORE_WIDTH     : natural;
            CLASS_IDX_WIDTH : natural
        );
        port (
            score_a_input    : in  std_logic_vector(SCORE_WIDTH - 1 downto 0);
            score_b_input    : in  std_logic_vector(SCORE_WIDTH - 1 downto 0);
            class_a_input    : in  std_logic_vector(CLASS_IDX_WIDTH - 1 downto 0);
            class_b_input    : in  std_logic_vector(CLASS_IDX_WIDTH - 1 downto 0);
            loser_idx_output : out std_logic_vector(CLASS_IDX_WIDTH - 1 downto 0)
        );
    end component;
    
    -- We need registers in the PU to have information like class assignments to PEs
    signal PE_acc_clear       : std_logic_vector(NBR_ACC - 1 downto 0);
    signal PE_acc_enable      : std_logic_vector(NBR_ACC - 1 downto 0);
    signal PE_acc_enable_safe : std_logic_vector(NBR_ACC - 1 downto 0);
    signal PE_load_next       : std_logic_vector(NBR_ACC - 1 downto 0);
    signal PE_load_reg        : std_logic_vector(NBR_ACC - 1 downto 0);
    signal PE_done            : std_logic_vector(NBR_ACC - 1 downto 0);

    signal MEM_addr_seg : std_logic_vector(SEG_ADDR_WIDTH - 1 downto 0);

    signal PE_class_next : bus_array(0 to NBR_ACC - 1)(CLASS_IDX_WIDTH - 1 downto 0);
    signal PE_class_reg  : bus_array(0 to NBR_ACC - 1)(CLASS_IDX_WIDTH - 1 downto 0);

    signal compare_class_a  : std_logic_vector(CLASS_IDX_WIDTH - 1 downto 0);
    signal compare_class_b  : std_logic_vector(CLASS_IDX_WIDTH - 1 downto 0);
    signal findmax_maxIdx   : std_logic_vector(CLASS_IDX_WIDTH - 1 downto 0);
    signal compare_pair_idx : std_logic_vector(PAIR_WIDTH - 1 downto 0);
    signal round_idx        : std_logic_vector(ROUND_WIDTH - 1 downto 0);

    signal score_a : std_logic_vector(SCORE_WIDTH - 1 downto 0);
    signal score_b : std_logic_vector(SCORE_WIDTH - 1 downto 0);

    signal class_seg_out    : bus_array(0 to NBR_CLASS_NEXT_POW2 - 1)(SEGMENT_WIDTH - 1 downto 0);
    signal selected_bhv_seg : bus_array(0 to NBR_ACC - 1)(SEGMENT_WIDTH - 1 downto 0);
    signal query_seg_out    : std_logic_vector(SEGMENT_WIDTH - 1 downto 0);

    signal PE_HamDist : bus_array(0 to NBR_ACC - 1)(HD_WIDTH - 1 downto 0);

begin
    
    -- Register holding load and class values
    process(clk, rstn)
    begin
        if rstn = '0' then
            PE_load_reg  <= (others => '0');
            PE_class_reg <= (others => (others => '0'));
        elsif rising_edge(clk) then
            PE_load_reg  <= PE_load_next;
            PE_class_reg <= PE_class_next;
        end if;
    end process;

    FSMD_0 : FSMD
        generic map (
            NBR_CLASS           => NBR_CLASS,
            NBR_CLASS_NEXT_POW2 => NBR_CLASS_NEXT_POW2,
            VECTOR_WIDTH        => VECTOR_WIDTH,
            SLICE_WIDTH         => SLICE_WIDTH,
            SEGMENT_WIDTH       => SEGMENT_WIDTH
        )
        port map (
            clk                             => clk,
            rstn                            => rstn,
            fsmd_start_input                => PU_start_input,
            fsmd_ready_output               => PU_ready_output,
            fsmd_PE_acc_clear_output        => PE_acc_clear,
            fsmd_PE_acc_enable_output       => PE_acc_enable,
            fsmd_PE_load_output             => PE_load_next,
            fsmd_PE_done_input              => PE_done,
            fsmd_MEM_addr_seg_output        => MEM_addr_seg,
            fsmd_PE_class_output            => PE_class_next,
            fsmd_compare_class_a_output     => compare_class_a,
            fsmd_compare_class_b_output     => compare_class_b,
            fsmd_compare_pair_idx_output    => compare_pair_idx,
            fsmd_round_idx_output           => round_idx,
            fsmd_findmax_maxIdx_input       => findmax_maxIdx,
            fsmd_predicted_class_idx_output => PU_predicted_class_idx_output
        );
    
    -- We want to generate one class hypervector ROM per PE
    gen_CLASS_ROM : for i in 0 to NBR_CLASS_NEXT_POW2 - 1 generate
        CLASS_ROM_i : CLASS_ROM
            generic map (
                CLASS_ID      => i,
                SEGMENT_WIDTH => SEGMENT_WIDTH,
                NBR_SEG       => NBR_SEG
            )
            port map (
                clk            => clk,
                addr_seg_input => MEM_addr_seg,
                segment_output => class_seg_out(i)
            );
    end generate;
    
    -- We just need one Query Hypervector ROM
    QUERY_ROM_0 : QUERY_ROM
        generic map (
            ADDR_OFFSET_QHV => ADDR_OFFSET_QHV,
            NBR_QUERY       => NBR_QUERY,
            SEGMENT_WIDTH   => SEGMENT_WIDTH,
            NBR_SEG         => NBR_SEG
        )
        port map (
            clk             => clk,
            query_idx_input => PU_query_idx_input,
            addr_seg_input  => MEM_addr_seg,
            segment_output  => query_seg_out
        );
    
    -- Here we create the muxes that connect the ROM to the PEs, to optimize it,
    -- we use the tournament's symmetry to create two groups, where we connect the 
    -- classes based on the group it's in.
    gen_PE_select : for i in 0 to NBR_ACC - 1 generate
        constant GROUP_CLASSES    : natural := NBR_CLASS_NEXT_POW2 / 2;
        constant GROUP_IDX_WIDTH  : natural := CLASS_IDX_WIDTH - 1;
        -- In this line, if we're in the first group, i / GROUP_CLASSES = 0
        -- However, if we're in the second group, i / GROUP_CLASSES = 1
        constant GROUP_BASE_CLASS : natural := (i / GROUP_CLASSES) * GROUP_CLASSES;

        signal group_class_seg : bus_array(0 to GROUP_CLASSES - 1)(SEGMENT_WIDTH - 1 downto 0);
        signal group_class_idx : integer range 0 to GROUP_CLASSES - 1;
    begin
        -- For every PE, we generate the possible inputs (all classes in your group)
        gen_group_class_inputs : for j in 0 to GROUP_CLASSES - 1 generate
            group_class_seg(j) <= class_seg_out(GROUP_BASE_CLASS + j);
        end generate;
        
        -- We assign a local id based on the group you're in (with 32 classes, class 19 becomes id 4 in group 2)
        group_class_idx <= to_integer(unsigned(PE_class_reg(i)(GROUP_IDX_WIDTH - 1 downto 0)));
        
        -- Input of mux
        selected_bhv_seg(i) <= group_class_seg(group_class_idx);
        
        -- Enable to load a PE's buffer
        PE_acc_enable_safe(i) <= PE_acc_enable(i) and not PE_load_reg(i);

    end generate;

    gen_PE : for i in 0 to NBR_ACC - 1 generate
        HD_PE_i : HD_PE
            generic map (
                VECTOR_WIDTH  => VECTOR_WIDTH,
                SLICE_WIDTH   => SLICE_WIDTH,
                SEGMENT_WIDTH => SEGMENT_WIDTH
            )
            port map (
                clk                  => clk,
                rstn                 => rstn,
                PE_acc_clear_input   => PE_acc_clear(i),
                PE_acc_enable_input  => PE_acc_enable_safe(i),
                PE_load_input        => PE_load_reg(i),
                PE_segment_BHV_input => selected_bhv_seg(i),
                PE_segment_QHV_input => query_seg_out,
                PE_done_output       => PE_done(i),
                PE_HamDist_output    => PE_HamDist(i)
            );
    end generate;

    SCORE_ACCUMULATOR_0 : SCORE_ACCUMULATOR
        generic map (
            NBR_ACC     => NBR_ACC,
            HD_WIDTH    => HD_WIDTH,
            SCORE_WIDTH => SCORE_WIDTH,
            ROUND_WIDTH => ROUND_WIDTH,
            PAIR_WIDTH  => PAIR_WIDTH
        )
        port map (
            PE_HamDist_input => PE_HamDist,
            round_idx_input  => round_idx,
            pair_idx_input   => compare_pair_idx,
            score_a_output   => score_a,
            score_b_output   => score_b
        );
    
    findMax_0 : findMax
        generic map (
            SCORE_WIDTH     => SCORE_WIDTH,
            CLASS_IDX_WIDTH => CLASS_IDX_WIDTH
        )
        port map (
            score_a_input    => score_a,
            score_b_input    => score_b,
            class_a_input    => compare_class_a,
            class_b_input    => compare_class_b,
            loser_idx_output => findmax_maxIdx
        );

end architecture Behavioral;