library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

library work;
use work.HD_Package.ALL;

entity FSMD is
    generic (
        NBR_CLASS           : natural := 6;
        NBR_CLASS_NEXT_POW2 : natural := 8;
        VECTOR_WIDTH        : natural := 8192;
        SLICE_WIDTH         : natural := 32;
        SEGMENT_WIDTH       : natural := 512
    );
    port (
        clk  : in std_logic;
        rstn : in std_logic;

        fsmd_start_input  : in  std_logic;
        fsmd_ready_output : out std_logic;

        fsmd_PE_acc_clear_output  : out std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);
        fsmd_PE_acc_enable_output : out std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);
        fsmd_PE_load_output       : out std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);
        fsmd_PE_done_input        : in  std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);

        fsmd_MEM_addr_seg_output : out std_logic_vector(log2c((VECTOR_WIDTH / SEGMENT_WIDTH) - 1) - 1 downto 0);

        fsmd_PE_class_output : out bus_array(0 to NBR_CLASS_NEXT_POW2 - 1)(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1 downto 0);

        fsmd_compare_class_a_output : out std_logic_vector(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1 downto 0);
        fsmd_compare_class_b_output : out std_logic_vector(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1 downto 0);

        fsmd_compare_pair_idx_output : out std_logic_vector(log2c((NBR_CLASS_NEXT_POW2 / 2) - 1) - 1 downto 0);
        fsmd_round_idx_output        : out std_logic_vector(log2c(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1) - 1 downto 0);

        fsmd_findmax_maxIdx_input : in std_logic_vector(log2c(NBR_CLASS_NEXT_POW2 - 1) - 1 downto 0);

        fsmd_predicted_class_idx_output : out std_logic_vector(log2c(NBR_CLASS - 1) - 1 downto 0)
    );
end entity;

architecture Behavioral of FSMD is

    constant NBR_SEG         : natural := VECTOR_WIDTH / SEGMENT_WIDTH;
    constant SEG_ADDR_WIDTH  : natural := log2c(NBR_SEG - 1);
    constant CLASS_IDX_WIDTH : natural := log2c(NBR_CLASS_NEXT_POW2 - 1);
    constant NBR_ROUNDS      : natural := log2c(NBR_CLASS_NEXT_POW2 - 1);
    constant ROUND_WIDTH     : natural := log2c(NBR_ROUNDS - 1);
    constant PAIR_WIDTH      : natural := log2c((NBR_CLASS_NEXT_POW2 / 2) - 1);
    
    -- We have new states:
    -- LOAD_AND_ACCUM: Used when loading a class's PE and accumulating at the same time (When a class has more than one PE)
    -- WAIT_DONE: Wait for a class to fully accumulate all PEs
    -- COMPARE_AND_WINNER: We compare the classes, find the winner, and clear the PEs of the loser
    type state_type is (IDLE, LOAD_AND_ACCUM, WAIT_DONE, COMPARE_AND_WINNER);
    type class_array is array(0 to NBR_CLASS_NEXT_POW2 - 1) of integer range 0 to NBR_CLASS_NEXT_POW2 - 1;

    -- Registers
    signal state_reg  : state_type;
    signal state_next : state_type;

    signal round_idx_reg, round_idx_next : unsigned(ROUND_WIDTH - 1 downto 0);
    signal pair_idx_reg,  pair_idx_next  : unsigned(PAIR_WIDTH - 1 downto 0);

    signal load_idx_reg, load_idx_next : integer range 0 to NBR_CLASS_NEXT_POW2;

    signal winner_reg, winner_next : class_array;
    signal winner_stage_reg, winner_stage_next : class_array;

    signal pe_done_reg, pe_done_next : std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);

    signal predicted_class_idx_reg  : std_logic_vector(log2c(NBR_CLASS - 1) - 1 downto 0);
    signal predicted_class_idx_next : std_logic_vector(log2c(NBR_CLASS - 1) - 1 downto 0);
    
    signal n_pe_per_class : integer range 1 to NBR_CLASS_NEXT_POW2 := 1;

begin
    
    -- Registers
    process(clk, rstn)
    begin
        if rstn = '0' then
            state_reg <= IDLE;
            round_idx_reg <= (others => '0');
            pair_idx_reg <= (others => '0');
            load_idx_reg <= 0;
            winner_reg <= (others => 0);
            winner_stage_reg <= (others => 0);
            pe_done_reg <= (others => '0');
            predicted_class_idx_reg <= (others => '0');

        elsif rising_edge(clk) then
            state_reg <= state_next;
            round_idx_reg <= round_idx_next;
            pair_idx_reg <= pair_idx_next;
            load_idx_reg <= load_idx_next;
            winner_reg <= winner_next;
            winner_stage_reg <= winner_stage_next;
            pe_done_reg <= pe_done_next;
            predicted_class_idx_reg <= predicted_class_idx_next;
        end if;
    end process;

    process(state_reg, round_idx_reg, pair_idx_reg, load_idx_reg,
            winner_reg, winner_stage_reg, pe_done_reg, predicted_class_idx_reg,
            fsmd_start_input, fsmd_PE_done_input, fsmd_findmax_maxIdx_input, n_pe_per_class)

        variable n_pairs      : integer range 1 to NBR_CLASS_NEXT_POW2 / 2;
        variable group_offset : integer range 0 to NBR_CLASS_NEXT_POW2 - 1;
        variable mem_seg_addr : integer range 0 to NBR_SEG - 1;

        variable class_a : integer range 0 to NBR_CLASS_NEXT_POW2 - 1;
        variable class_b : integer range 0 to NBR_CLASS_NEXT_POW2 - 1;
        variable loser   : integer range 0 to NBR_CLASS_NEXT_POW2 - 1;
        variable winner  : integer range 0 to NBR_CLASS_NEXT_POW2 - 1;

        variable all_done    : boolean;
        variable pe_done_now : std_logic_vector(NBR_CLASS_NEXT_POW2 - 1 downto 0);
        
    begin
        state_next <= state_reg;
        round_idx_next <= round_idx_reg;
        pair_idx_next <= pair_idx_reg;
        load_idx_next <= load_idx_reg;
        winner_next <= winner_reg;
        winner_stage_next <= winner_stage_reg;
        pe_done_next <= pe_done_reg;
        predicted_class_idx_next <= predicted_class_idx_reg;

        fsmd_ready_output <= '0';
        fsmd_PE_acc_clear_output <= (others => '0');
        fsmd_PE_acc_enable_output <= (others => '0');
        fsmd_PE_load_output <= (others => '0');
        fsmd_MEM_addr_seg_output <= (others => '0');

        fsmd_compare_class_a_output <= (others => '0');
        fsmd_compare_class_b_output <= (others => '0');
        fsmd_compare_pair_idx_output <= std_logic_vector(pair_idx_reg);
        fsmd_round_idx_output <= std_logic_vector(round_idx_reg);
        

        -- Number of pairs being compared this round: the full class
        -- count split into groups of n_pe_per_class, then paired up two
        -- groups at a time.
        n_pairs := NBR_CLASS_NEXT_POW2 / (2 * n_pe_per_class);

        class_a := winner_reg(2 * to_integer(pair_idx_reg));
        class_b := winner_reg(2 * to_integer(pair_idx_reg) + 1);

        loser := to_integer(unsigned(fsmd_findmax_maxIdx_input));
        winner := class_a;

        pe_done_now := pe_done_reg or fsmd_PE_done_input;

        case state_reg is
            
            -- IDLE State, refreshes the values
            when IDLE =>
                fsmd_ready_output <= '1';
                fsmd_PE_acc_clear_output <= (others => '1');

                if fsmd_start_input = '1' then
                    for i in 0 to NBR_CLASS_NEXT_POW2 - 1 loop
                        winner_next(i) <= i;
                        winner_stage_next(i) <= i;
                    end loop;

                    round_idx_next <= (others => '0');
                    pair_idx_next <= (others => '0');
                    load_idx_next <= 0;
                    pe_done_next <= (others => '0');

                    state_next <= LOAD_AND_ACCUM;
                end if;
            
            -- LOAD_AND_ACCUM State, andles the individual loading and accumulating of PEs
            -- In the same state since it can be done in parallel for the same class
            when LOAD_AND_ACCUM =>
                pe_done_next <= pe_done_now;

                if load_idx_reg < n_pe_per_class then
                    -- Segment of the class (seg 1 -> seg 2 and 3 -> seg 4,5,6 and 7...)
                    mem_seg_addr := (n_pe_per_class - 1) + load_idx_reg;

                    fsmd_MEM_addr_seg_output <= std_logic_vector(to_unsigned(mem_seg_addr, SEG_ADDR_WIDTH));
                    
                    -- We load each PE ith the same segment (If each class has one PE, each first PE gets loaded 
                    -- with its segment, afterwards each second PE of each class gets loaded)
                    for i in 0 to NBR_CLASS_NEXT_POW2 - 1 loop
                        group_offset := i mod n_pe_per_class;

                        if group_offset = load_idx_reg then
                            fsmd_PE_load_output(i) <= '1';
                        elsif group_offset < load_idx_reg then
                            if pe_done_now(i) = '0' then
                                fsmd_PE_acc_enable_output(i) <= '1';
                            end if;
                        end if;
                    end loop;

                    load_idx_next <= load_idx_reg + 1;

                else
                    state_next <= WAIT_DONE;
                end if;
            
            -- WAIT_DONE State, we need to wait for all a classe's PE to be done before
            -- adding up the score and doing findMax
            when WAIT_DONE =>
                -- We set to true, and then look if all the done flags are enabled, if one of them
                -- is not, then we set the all_done flag to false.
                all_done := true;

                for i in 0 to NBR_CLASS_NEXT_POW2 - 1 loop
                    if pe_done_reg(i) = '0' then
                        fsmd_PE_acc_enable_output(i) <= '1';
                    end if;

                    if pe_done_now(i) = '0' then
                        all_done := false;
                    end if;
                end loop;

                pe_done_next <= pe_done_now;
                
                -- Only when everything is done do we go to the compare
                if all_done then
                    pair_idx_next <= (others => '0');
                    state_next <= COMPARE_AND_WINNER;
                end if;
            
            -- COMPARE_AND_WINNER State, compares the two classes, finds the winner, and clears the PE
            when COMPARE_AND_WINNER =>
                
                -- Compare
                fsmd_compare_class_a_output <= std_logic_vector(to_unsigned(class_a, CLASS_IDX_WIDTH));

                fsmd_compare_class_b_output <= std_logic_vector(to_unsigned(class_b, CLASS_IDX_WIDTH));

                fsmd_compare_pair_idx_output <= std_logic_vector(pair_idx_reg);
                fsmd_round_idx_output <= std_logic_vector(round_idx_reg);
                
                -- Find the winner
                if loser = class_a then
                    winner := class_b;
                else
                    winner := class_a;
                end if;

                winner_stage_next(to_integer(pair_idx_reg)) <= winner;
                
                -- We clear the PE of the loser (we need it's accumulated score to go back to 0)
                if n_pairs /= 1 then
                    if loser = class_a then
                        for i in 0 to NBR_CLASS_NEXT_POW2 - 1 loop
                            if (i >= (2 * to_integer(pair_idx_reg) * n_pe_per_class)) and
                               (i <  ((2 * to_integer(pair_idx_reg) + 1) * n_pe_per_class)) then
                                fsmd_PE_acc_clear_output(i) <= '1';
                            end if;
                        end loop;

                    else
                        for i in 0 to NBR_CLASS_NEXT_POW2 - 1 loop
                            if (i >= ((2 * to_integer(pair_idx_reg) + 1) * n_pe_per_class)) and
                               (i <  ((2 * to_integer(pair_idx_reg) + 2) * n_pe_per_class)) then
                                fsmd_PE_acc_clear_output(i) <= '1';
                            end if;
                        end loop;
                    end if;
                end if;
                
                -- If we've reached the final pair, then it's the end
                if n_pairs = 1 then
                    predicted_class_idx_next <= std_logic_vector(to_unsigned(winner, predicted_class_idx_next'length));
                    state_next <= IDLE;
                
                -- If we're done with all the pairs, then we move onto the next round
                -- and create the new bracket
                elsif to_integer(pair_idx_reg) = n_pairs - 1 then
                    for i in 0 to NBR_CLASS_NEXT_POW2 - 1 loop
                        winner_next(i) <= winner_stage_reg(i);
                    end loop;

                    winner_next(to_integer(pair_idx_reg)) <= winner;

                    round_idx_next <= round_idx_reg + 1;
                    pair_idx_next <= (others => '0');
                    load_idx_next <= 0;
                    pe_done_next <= (others => '0');

                    state_next <= LOAD_AND_ACCUM;
                -- Otherwise we move onto the next pair
                else
                    pair_idx_next <= pair_idx_reg + 1;
                    state_next <= COMPARE_AND_WINNER;
                end if;

        end case;
    end process;
    
    n_pe_per_class <= 2 ** to_integer(round_idx_reg);
    
    -- Here we reassign the classes to PEs (assign which class each PE represents)
    process(winner_reg, n_pe_per_class)
        variable group_idx : integer range 0 to NBR_CLASS_NEXT_POW2 - 1;
        variable class_i   : integer range 0 to NBR_CLASS_NEXT_POW2 - 1;
    begin
        for i in 0 to NBR_CLASS_NEXT_POW2 - 1 loop
            group_idx := i / n_pe_per_class;
            class_i := winner_reg(group_idx);
    
            fsmd_PE_class_output(i) <= std_logic_vector(to_unsigned(class_i, CLASS_IDX_WIDTH));
        end loop;
    end process;

    fsmd_predicted_class_idx_output <= predicted_class_idx_reg;

end Behavioral;